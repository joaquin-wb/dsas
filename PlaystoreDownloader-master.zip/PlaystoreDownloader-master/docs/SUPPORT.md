# Support

If you'd like to report an issue, suggest a feature or simply ask a question, please do
so on the [issues page](https://github.com/ClaudiuGeorgiu/PlaystoreDownloader/issues).

If you *really* need to contact the developers directly, you can find an email address
in the git commit history (support requests via email will be ignored, please use
[issues](https://github.com/ClaudiuGeorgiu/PlaystoreDownloader/issues)).
