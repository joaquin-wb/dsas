#!/usr/bin/env python3

from playstoredownloader.cli.cli import cli

cli()
